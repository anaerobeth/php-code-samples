<?php
defined('is_running') or die('Not an entry point...');
includeFile('tool/Images.php');
